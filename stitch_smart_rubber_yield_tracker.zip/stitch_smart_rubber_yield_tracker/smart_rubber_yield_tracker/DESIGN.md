---
name: Smart Rubber Yield Tracker
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#00b2d0'
  on-tertiary-container: '#003f4b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an agricultural intelligence platform built specifically for Thai rubber farmers, plantation managers, and agricultural cooperatives. Balancing harsh outdoor field realities with cutting-edge agronomic analytics, the interface fuses functional field-grade utility with contemporary dark-mode data engineering aesthetics.

### Visual Style
The design style is **Modern Technical Precision** rooted in utility-first dark architecture:
- Deep obsidian and charcoal slate surfaces eliminate battery drain and reduce harsh sunlight glare.
- High-contrast phosphorescent emerald accents convey lush plantation vitality and operational efficiency.
- Warm harvest gold highlights track market fluctuations, latex quality grading, and direct revenue yields.
- Tactile, well-defined micro-borders delineate dense sensory and telemetry data without visual clutter.

### Tone & Emotional Resonance
The interface projects resilience, clarity, trust, and prosperity. Farmers in high-humidity canopy conditions experience an uncluttered, responsive dashboard that respects ambient daylight extremes while projecting the authoritative sophistication of high-level financial and logistics software.

## Colors

The color palette is engineered specifically for outdoor OLED visibility, low-light night-tapping shifts, and precise telemetry scanning.

- **Primary (`#10B981` Emerald / `#059669` Deep Emerald):** Represents wet rubber latex production, healthy canopy NDVI indexes, active tapping operational statuses, and positive yield deltas.
- **Secondary (`#F59E0B` Amber Gold / `#D97706` Burnished Ochre):** Dictates financial metrics, current market prices (Central Rubber Market Songkhla parity), dry rubber content (DRC %) revenue tiers, and pending inspection alerts.
- **Tertiary (`#06B6D4` Cyan / Aqua):** Utilized for weather metrics, rainfall sensor gauges, soil moisture levels, and automated cup-cover actuator states.
- **Neutral (`#0F172A` Obsidian Base / `#1E293B` Elevated Slate / `#334155` Structural Border):** Form the layered dark architecture, minimizing eye strain while framing high-visibility metrics.
- **Critical / Pest Alert (`#EF4444` Crimson):** Reserved strictly for leaf fall disease warnings, fungal alerts, price drops, and perimeter intrusion alarms.

## Typography

Typography prioritizes bilingual harmony between Thai and Latin scripts, rapid numeric scanning, and zero layout shift during real-time data streaming.

### Font Pairings & Script Handling
- **Primary Interface Font:** `Inter` paired cleanly with standard system fallbacks (`Prompt`, `Sarabun`, `-apple-system`). Inter’s tall x-height and open apertures seamlessly match modern looped/loopless Thai letterforms, preventing glyph clipping across multi-line harvest records.
- **Monospaced Technical Font:** `JetBrains Mono` handles all numerical yield outputs (e.g., kg/rai, DRC percentages, THB spot prices, timestamped scale inputs). Tabular numbers align perfectly down data grids.

### Outdoor & Field Readability Rules
1. Never render dynamic numeric values lighter than `500` font weight.
2. Thai body text maintains a minimum line-height multiplier of `1.6` to avoid tone-mark crowding with uppercase numerals.
3. Micro-labels always employ uppercase formatting with generous character spacing to maximize readability through protective screen shields or moisture film.

## Layout & Spacing

Field operations require rapid single-hand tapping on smartphones, while plantation management dashboards demand deep, responsive widescreen monitor grids.

### Responsive Breakpoints & Grid System
- **Mobile (< 768px):** Single-column fluid stack with strict 48px minimum touch targets. 12px horizontal gutters with persistent bottom navigation optimized for thumb reach while wearing tapping gloves.
- **Tablet (768px – 1024px):** 6-column fluid grid. Split view balancing zone-level satellite maps on the left with live weighing scale data on the right.
- **Desktop (> 1024px):** 12-column fixed-max grid (1440px container) with a collapsible operational sidebar, allowing modular rearrangement of sensor widgets, price tickers, and inventory batches.

### Spacing Philosophy
Layout spacing adheres to an 8-point base grid. Spacing is intentionally generous around actionable targets (`space-lg`) to prevent mis-taps when entering wet weights or adjusting chemical balances in wet conditions. Dense spacing (`space-xs`, `space-sm`) is strictly reserved for internal card telemetry tags and data chips.

## Elevation & Depth

Visual depth is achieved through structural color zoning, low-contrast ghost borders, and focused ambient emerald luminance rather than heavy drop shadows, maintaining outdoor contrast integrity.

### Surface Tiers
- **Tier 0 (Canvas Base):** `#0F172A` (Rich Obsidian Slate) - Anchors the entire viewport.
- **Tier 1 (Cards & Modular Panes):** `#1E293B` (Elevated Slate) - Houses plots, live scale readings, and yield trend charts.
- **Tier 2 (Modals, Overlays & Action Sheets):** `#334155` (Mid Slate) - For quick weight entry popups and barcode scanners.
- **Tier 3 (Floating Controls):** `#475569` with 60% opacity and 12px backdrop-filter blur.

### Borders & Glowing Accents
- Standard cards use a crisp `1px solid #334155` border.
- Active states, focused data inputs, and high-yield alerts replace the border with `1px solid #10B981` accompanied by a localized ambient glow: `box-shadow: 0 0 16px -2px rgba(16, 185, 129, 0.25)`.
- Critical market swings or low-yield warnings trigger an amber ambient state: `box-shadow: 0 0 16px -2px rgba(245, 158, 11, 0.2)`.

## Shapes

The design system incorporates a balanced **Rounded (`2`)** shape architecture (8px baseline radius for controls, 16px for primary containers). This softens the harshness of technical telemetry charts while remaining sufficiently structured for dense data matrices.

### Radii Hierarchy
- **Standard Controls (Inputs, Buttons, Micro-tags):** `0.5rem` (8px). Delivers a modern, click-friendly surface area.
- **Content Cards & Panels:** `rounded-lg` (`1rem` / 16px). Forms clean modular pods that isolate distinct rubber parcel metrics.
- **Sheet Overlays & Map Insets:** `rounded-xl` (`1.5rem` / 24px). Creates friendly, non-abrasive boundaries for bottom drawer interactions on mobile devices.
- **Status Pills & Metric Badges:** Fully circular (`rounded-full` / 9999px) to clearly distinguish metadata from clickable action buttons.

## Components

### Buttons & Interactive Controls
- **Primary Action (Confirm Yield / Start Session):** High-contrast emerald background (`#10B981`) with dark slate typography (`#0F172A`), weight `600`. Heights: 48px mobile, 40px desktop. Includes subtle active scale transition (`scale(0.98)`).
- **Secondary Action (Filter / Export Sheet):** Transparent fill with a `1px solid #334155` outline and `#F8FAFC` text. On hover: border transitions to `#10B981`.
- **Destructive / Reset:** Semi-transparent crimson (`rgba(239, 68, 68, 0.15)`) with `#EF4444` text and border.

### Input Fields & Scale Integrations
- Text and number fields display an elevated slate fill (`#1E293B`) with a `1px solid #334155` default perimeter.
- Inputs feature persistent, right-aligned measurement units (`กก.` / `kg`, `% DRC`, `฿/กก.`) rendered in `JetBrains Mono` (`#94A3B8`).
- Touch keyboard inputs trigger an emerald border focus ring and auto-select values for rapid field entry during heavy weighing cycles.

### Metric Cards & Telemetry Containers
- Enclosed modules with `#1E293B` backgrounds and a 1px border.
- Headers separate plot identifiers (e.g., *แปลง A-04 (Zone A)*) on the left from weather/status indicator badges on the right.
- Numerical readouts use large tabular weights (`headline-xl` or `headline-lg`) flanked by micro trend pills indicating 24-hour yield shifts.

### Status Indicators & Badges
- **Status Badges:** Compact pills with semi-transparent tinted backgrounds (`rgba(16, 185, 129, 0.15)` for Normal / Green, `rgba(245, 158, 11, 0.15)` for Inspection Needed / Amber, `rgba(239, 68, 68, 0.15)` for Rain / Stop Tapping).
- Feature a solid 6px pulsating dot beside the localized label text for quick peripheral scanning.

### Specialized Agricultural Components
- **DRC (Dry Rubber Content) Dial:** Radial SVG gauge measuring moisture vs. solid rubber percentage with high-visibility color thresholds.
- **Plot Health Strip:** Segmented progress strip color-coded by tree tapping rotation cycles (e.g., d3, d4 intervals) preventing bark damage.
- **Live Rubber Price Ticker:** Persistent marquee or top ribbon tracking latest Songkhla rubber market benchmarks (Raw Sheet, Latex, Cup Lump) with dynamic delta indicators.